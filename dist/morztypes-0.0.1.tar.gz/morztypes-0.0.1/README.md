# Morztypes
My small python library for types like Vector2&amp;3
